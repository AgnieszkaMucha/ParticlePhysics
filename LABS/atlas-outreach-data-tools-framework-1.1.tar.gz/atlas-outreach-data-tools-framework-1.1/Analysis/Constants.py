"""Module defining some often needed constants
"""

Z_Mass = 91.188;