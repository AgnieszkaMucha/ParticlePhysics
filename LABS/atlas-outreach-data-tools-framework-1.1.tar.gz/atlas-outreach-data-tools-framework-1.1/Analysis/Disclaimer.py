message = """
---------------------DISCLAIMER---------------------
This Software is intended for educational use only!
Under no circumstances does it qualify to reproduce
actual ATLAS analysis results or produce publishable
results!
----------------------------------------------------
"""


def printDisclaimer():
  print message